export TMUX_TMPDIR=/data/data/com.wizkterm/files/usr/var/run
