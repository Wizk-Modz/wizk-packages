#!/data/data/com.wizkterm/files/usr/bin/sh

echo "$@"
