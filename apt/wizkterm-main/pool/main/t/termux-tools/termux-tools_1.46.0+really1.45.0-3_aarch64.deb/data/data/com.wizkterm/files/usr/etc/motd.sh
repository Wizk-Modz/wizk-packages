#!/data/data/com.wizkterm/files/usr/bin/bash

# Setup TERMUX_APP_PACKAGE_MANAGER
source "/data/data/com.wizkterm/files/usr/bin/termux-setup-package-manager" || exit 1

terminal_width="$(stty size | cut -d" " -f2)"
if [[ "$terminal_width" =~ ^[0-9]+$ ]] && [ "$terminal_width" -gt 60 ]; then

    motd="
 \e[47m                \e[0m  \e[1mWelcome to WizkTerm!\e[0m
 \e[47m  \e[0m            \e[0;37m\e[47m .\e[0m
 \e[47m  \e[0m  \e[47m  \e[0m        \e[47m  \e[0m  \e[1mRepo:\e[0m    \e[4mhttps://wizk-modz.github.io/wizk-packages\e[0m
 \e[47m  \e[0m  \e[47m  \e[0m        \e[47m  \e[0m  \e[1mIssues:\e[0m  \e[4mhttps://github.com/Wizk-Modz/wizk-packages/issues\e[0m
 \e[47m  \e[0m            \e[0;37m\e[47m .\e[0m
 \e[47m                \e[0m  \e[1mWizkTerm version:\e[0m ${TERMUX_VERSION-Unknown}
"

    motd_indent="                   "

else

    motd="
\e[1mWelcome to WizkTerm!\e[0m

\e[1mRepo:\e[0m    \e[4mhttps://wizk-modz.github.io/wizk-packages\e[0m
\e[1mIssues:\e[0m  \e[4mhttps://github.com/Wizk-Modz/wizk-packages/issues\e[0m

\e[1mWizkTerm version:\e[0m ${TERMUX_VERSION-Unknown}
"

    motd_indent=""
fi

motd+="
${motd_indent}\e[1mWorking with packages:\e[0m
${motd_indent}\e[1mSearch:\e[0m  pkg search <query>
${motd_indent}\e[1mInstall:\e[0m pkg install <package>
${motd_indent}\e[1mUpgrade:\e[0m pkg upgrade
"

if [ "$TERMUX_APP_PACKAGE_MANAGER" = "apt" ]; then

    motd+="
${motd_indent}\e[1mSubscribing to additional repos:\e[0m
${motd_indent}\e[1mRoot:\e[0m pkg install root-repo
${motd_indent}\e[1mX11:\e[0m  pkg install x11-repo
"

fi

motd+="
${motd_indent}Report issues at \e[4mhttps://github.com/Wizk-Modz/wizk-packages/issues\e[0m
"

echo -e "$motd"
