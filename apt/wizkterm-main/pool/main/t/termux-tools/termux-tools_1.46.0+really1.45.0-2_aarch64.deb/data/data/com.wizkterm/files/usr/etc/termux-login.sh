##
## This script is sourced by /data/data/com.wizkterm/files/usr/bin/login before executing shell.
##
