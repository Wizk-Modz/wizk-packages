if [ ! -f /data/data/com.wizkterm/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/com.wizkterm/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/com.wizkterm/files/home/.termux
	cp /data/data/com.wizkterm/files/usr/share/examples/termux/termux.properties /data/data/com.wizkterm/files/home/.termux/
fi
