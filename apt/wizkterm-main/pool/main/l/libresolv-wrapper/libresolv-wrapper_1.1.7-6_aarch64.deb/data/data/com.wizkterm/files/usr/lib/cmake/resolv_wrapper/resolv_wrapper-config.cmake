set(RESOLV_WRAPPER_LIBRARY /data/data/com.wizkterm/files/usr/lib/libresolv_wrapper.so)
